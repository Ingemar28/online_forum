<?php include('template/header.php'); ?>
<body id="forum">
<script>
</script>
<link href="https://cdn.jsdelivr.net/npm bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/css/forum.css">
<div class="body_container">
    <h2>
    </h2>
    <div class="row1">
        <?php
        if (isset($_SESSION['username'])) { ?>
            <div>
                <a href="post">New Post</a>
            </div>
        <?php } ?>
        <div>
            <button type="button">Categorie1</button>
        </div>
        <div>
            <button type="button">Categorie2</button>
        </div>
        <div>
            <button type="button">Categorie3</button>
        </div>
    </div>
    <div class="row2">
        <?php
        $servername = "mysql"; // This should match the service name in your Docker Compose file
        $dbUsername = "php";
        $dbPassword = "php";
        $dbName = "project";

        $conn = mysqli_connect($servername, $dbUsername, $dbPassword, $dbName);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $query = "SELECT * FROM post";
        $result = mysqli_query($conn, $query);

        if ($result) {
            $html = '';
            while ($row = mysqli_fetch_assoc($result)) {
                $html .= '<div class="post">';
                $html .= '<div>';
                $html .= '<img src="assets/img/user.png " alt="hero icon" class="img-fluid">';
                $html .= '<div><h3>' . $row['title'] . '</h3>';
                $html .= '<p>' . $row['content'] . '</p></div>';
                $html .= '</div>';
                $html .= '<div class="buttons">
                <button onclick="like(\'' . $row['id'] . '\')"><i class="bi bi-hand-thumbs-up-fill"></i>
                <span id="like' . $row['id'] . '"></span></button><br>';
                $html .= '</div>';
                $html .= '</div>';
            }
            echo $html;
        }
        ?>
    </div>
</div>
</body>
<?php include('template/footer.php'); ?>

