<body id="forum">
<script>
    function newComment(id){
        var text = document.getElementById("'"+id+"'").value;
        $.ajax({
        url: "<?php echo base_URL();?>forum/newComment",
        type: "POST",
        data: {'id': id, 'text': text},
        success: function(data) {
            // renew the comments 
            // console.log(data);
            location.reload();
        }
        });
        
    };

    function bookmark(id){
        $.ajax({
            url: "<?php echo base_URL();?>bookmark/bookmark",
            type: "POST",
            data: {id: id},
            dataType: "json",
            success: function(response) {
                alert(response);
            }
        });
    }

    
    // var socket = new WebSocket('wss://localhost:8080');
        
    // socket.onopen = function(event) {
    //     console.log('WebSocket connection established.');
    // };
    
    // socket.onmessage = function(event) {
    //     var message = JSON.parse(event.data);
    //     var messageElement = document.createElement('p');
    //     messageElement.innerText = message.text;
    //     document.getElementById('messages').appendChild(messageElement);
    // };
    
    // document.getElementById('message-form').addEventListener('submit', function(event) {
    //     event.preventDefault();
        
    //     var input = document.getElementById('message-input');
    //     var message = {
    //         text: input.value
    //     };
        
    //     socket.send(JSON.stringify(message));
    //     input.value = '';
    // });

</script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/forum.css">    
    <div class="body_container">
        <div class="row2">
        <?php 
            echo $html;
            // echo $test;
        ?>
        </div>
    </div>
</body>