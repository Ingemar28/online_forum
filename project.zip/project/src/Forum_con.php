<?php

namespace App\Controllers;
use App\Libraries\MongoDB;
use CodeIgniter\Controller;
use App\Models\PostModel;
use App\Models\UsersModel;
use App\Config\Services;
use GuzzleHttp\Client;
use PerspectiveApi\CommentsClient;
use PerspectiveApi\Generated\Model\AnalyzeCommentResponse;
// use Google\Cloud\Language\LanguageClient;

class Forum extends BaseController
{
    
    public function index()
    {
        $numberOfPosts = 0;
        $post = new PostModel();
        if (isset($_COOKIE['scrollTop']) && $_COOKIE['scrollTop'] > 1200){
            $posts = $post->getAllPosts();
        } else {
            $posts = $post->getPosts('date', $numberOfPosts, 5);
        }
        
        $html = $this->loadPost($posts, false);
        $data = ['html' => $html,
            'pager' => $post->pager];

        echo view('template/header');
        echo view('forum', $data);
        echo view('template/footer');
    }

    public function postCheck(){
        echo view('template/header');
        echo view('post');
        echo view('template/footer');
    }
        
    public function newComment()
    {
        $id = $_POST['id'];
        $text = $_POST['text'];
        $post = new PostModel();
        $post->addNewComment($id, $text);
        return redirect()->to(base_url('forum'));
    }

    public function loadMorePosts()
    {
        $numberOfPosts = intval($this->request->getPost('numberOfPosts'));
        $post = new PostModel();
        $posts = $post->getPosts('date', $numberOfPosts);
        $html = $this->loadPost($posts, false);
        return $html;
    }

    public function autoComplete()
    {
        $tokens = $this->request->getPost('tokens');
        $post = new PostModel();
        $posts = $post->autoComplete($tokens);

        $html = '';
        foreach($posts as $p){
            $html .= '<a href="#">'.$p->title.'</a>';
        }

        return $html;
    }

    public function search()
    {
        $search_input = $this->request->getPost('search_input');
        $tokens = explode(" ", $search_input);
        $post = new PostModel();
        $posts = $post->autoComplete($tokens);

        $html = $this->loadPost($posts, false);

        $data = ['html' => $html,
            'pager' => $post->pager];
        // $data = ['search_input' => $search_input];

        echo view('template/header');
        echo view('search', $data);
        echo view('template/footer');
    }

    public function posts($id)
    {
        $post = new PostModel();
        $posts = $post->getPost($id);
        // $data = ['test' => $posts->title];
        $html = $this->loadPost($posts, true);
        $data = ['html' => $html];
        echo view('template/header');
        echo view('posts', $data);
        echo view('template/footer');
    }

    public function like()
    {
        $id = $_POST['id'];
        $post = new PostModel();
        $result = $post->addLike($id);
        if ($result !== false) {
            foreach ($result as $document) {
                $response = $document->likes;
            }
        } else {
            $response = null;
        }
    
        echo json_encode($response);
    }

    public function loadPost($posts, $showComments, $showDelete = false) {
        $html = '';
        foreach ($posts as $p) 
        {    
            $html .= '<div class="post">';
            $html .= '<div>';
            $html .= '<img src="'.base_url().'assets/img/user.png " alt="hero icon" class="img-fluid">';

            $html .= '<div>
            <h3>'.$p->title.'</h3>';
            $html .= '<p>'.$p->context.'</p></div>';
            
            if (isset($p->file))
            {
                foreach ($p->file as $f)
                {
                    $filename = WRITEPATH . 'uploads/' . $f;
                    $imgData = base64_encode(file_get_contents($filename));
                    $html .= '<img src="data:image/png;base64,' . $imgData . '" alt="post image" class="img-fluid" style="width: 400px; height: auto;"/>';
                    // $html .= '<img src="'.base_url().'assets/img/'.$f.'" alt="hero icon" class="img-fluid">';
                }
            }

            if ($p->badge != "None")
            {
                $html .= '<p>'.$p->badges.'<p>';
            }

            $html .= '</div>';    
            
            $html .= '<div class="buttons">
            <button onclick="like(\''.$p->_id.'\')"><i class="bi bi-hand-thumbs-up-fill"></i>
            <span id="like'.$p->_id.'">'.$p->likes.'</span></button><br>';

            if ($showDelete){
                $html .= '<button onclick="deleteBookMark(\''.$p->_id.'\')" class="btn btn-primary" style="width:10%">
                Delete</button><br>';
            } else {
                $html .= '<button onclick="bookmark(\''.$p->_id.'\')" class="btn btn-primary" style="width:13%">
                Bookmark</button><br>';
            }

            if ($showComments && !empty($p->comments)){
                foreach ($p->comments as $comment){
                    $html .= '<p>'.$comment->text.'</p>';
                }
                $session = session();
                if ($session->get('username') || get_cookie('username')) {
                    $html .= '<textarea id="\''.$p->_id.'\'" name="context" rows="2" cols="30" placeholder="Enter comments here..."></textarea>';
                    $html .= '<button onclick="newComment(\''.$p->_id.'\')" class="btn btn-primary btn-sm">Add Comments</button>';           
                }
            } else {
                $html .= '<a href='.base_url().'forum/posts/'.$p->_id.'>See more</a>';
            }
            
            $html .= '</div>';

            $html .= '</div>';
        }
        return $html;
    }

}
