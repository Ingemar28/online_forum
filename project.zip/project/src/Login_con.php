<?php
if(!isset($_SESSION)){
    session_start();
}

$referrer = $_SERVER['HTTP_REFERER'];
$parts = parse_url($referrer);
$path = trim($parts['path'], '/');
$segments = explode('/', $path);
$lastSegment = end($segments);
$login = new Login();
if ($lastSegment == 'login.php') {
    $login->checkLogin();
} else {
    $login->logout();
}

class Login
{
    public function checkLogin()
    {
        $data['error'] = "<div class=\"alert alert-danger\" role=\"alert\"> Incorrect username or password!! </div> ";
        $username = $_POST['username'];
        $password = $_POST['password'];

        $servername = "mysql"; // This should match the service name in your Docker Compose file
        $dbUsername = "php";
        $dbPassword = "php";
        $dbName = "project";

        // Create connection
        $conn = mysqli_connect($servername, $dbUsername, $dbPassword, $dbName);

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // You need to run a query to fetch user data from your database and verify the user's credentials here.
        // For example:
        $query = "SELECT * FROM user WHERE username = '$username'";
        $result = mysqli_query($conn, $query);

        if ($result) {
            $user = mysqli_fetch_assoc($result);

            $dbPassword = $user['password']; // Adjust the field name as needed

            // Verify the input password against the stored password
            if ($password == $dbPassword) {
                $_SESSION['username'] = $username;
                $_SESSION['password'] = $password;
                $_SESSION['id'] = $user['id']; // Assuming there's an 'id' field in your database
                header("Location: forum.php");
                exit();
            } else {
                // Passwords do not match
                $data['error'] = "<div class=\"alert alert-danger\" role=\"alert\"> Username and Password incorrect! </div> ";
                header("Location: login.php");
                exit();
            }
        } else {
            $data['error'] = "<div class=\"alert alert-danger\" role=\"alert\"> Username and Password incorrect! </div> ";
            header("Location: login.php");
            exit();
        }

        mysqli_close($conn);
    }

    public function logout()
    {
        session_unset();
        session_destroy();
        setcookie('username', '', time() - 3600, "/");
        setcookie('password', '', time() - 3600, "/");
        setcookie('scrollTop', '', time() - 3600, "/");
        header("Location: login.php");
        exit();
    }
}
?>

