#!/bin/bash
if [ $# -eq 0 ]
then
    echo "No arguments provided, please use the command: sudo chmod +x quiz1-submission.sh && ./quiz1-submission.sh s4xxxxxx"
    echo 'e.g. ./quiz1-submission.sh s4123456'
    echo 'Failed to zip the files for Quiz 1 submission.'
    exit 1
fi

echo 'Zipping quiz files...'
sudo chmod -R 777 /var/www/htdocs/mock
cd /var/www/htdocs/mock

# Zip the quiz files. If the zip already exsits, remove it first.
rm /var/www/htdocs/mock/$1_quiz1.zip 2> /dev/null
zip -j "$1_quiz1.zip" ./app/Config/Routes.php ./app/Controllers/Quiz1.php ./app/Views/input.php ./app/Views/output.php

if [ $? -eq 0 ]
then
    echo 'Successfully zipped the files for submission.'
    echo "Your zip file for submission is located at /var/www/htdocs/mock/$1_quiz1.zip"
    echo "Please download it to your own computer using VSCode (right-click on the file -> Download) or scp command (scp sxxxxxxx@infs3202-xxxxxxxx.zones.eait.uq.edu.au:/var/www/htdocs/mock/$1_quiz1.zip ~), then upload it to the Blackboard."
    exit 0
else
    echo 'Failed to zip the files for Quiz 1 submission.'
    exit 1
fi
