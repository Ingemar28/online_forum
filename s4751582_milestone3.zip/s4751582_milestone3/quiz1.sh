#!/bin/bash
if [ $# -eq 0 ]
then
    echo "No arguments provided, please use the command: sudo chmod +x quiz1.sh && ./quiz1.sh s4xxxxxx"
    echo 'e.g. ./quiz1.sh s4123456'
    echo 'Failed to set up Quiz 1 environment.'
    exit 1
fi

# Check if the mock folder exists
if ! cd /var/www/htdocs/mock;
then
  echo "Error: Your /var/www/htdocs/mock folder does not exist. Please follow the Mock Quiz 1 instructions first."
  echo 'Failed to set up Quiz 1 environment.'
  exit 1
fi

# Download the quiz zip file
echo 'Downloading quiz files...'
cd /var/www/htdocs/mock
sudo apt-get install --no-install-recommends --no-install-suggests -q -y zip wget
wget --no-check-cert https://www.dropbox.com/s/v3b5mc2i0zuldyt/quiz_code_empty.zip
unzip -o quiz_code_empty.zip
rm quiz_code_empty.zip

# Make a backup of the original mock folder. If the backup folder already exists, remove it first.
sudo rm -rf /var/www/htdocs/mock-old 2> /dev/null
sudo chmod -R 777 /var/www/htdocs/mock
cp -R /var/www/htdocs/mock /var/www/htdocs/mock-old
sudo chmod -R 777 /var/www/htdocs/mock-old
sudo rm -rf /var/www/htdocs/mock/app/Controllers/*.php
sudo rm -rf /var/www/htdocs/mock/app/Views/*.php
sudo rm -rf /var/www/htdocs/mock/app/Models/*.php

# Move the files to the Controller and View
echo 'Moving quiz files...'
cp /var/www/htdocs/mock-old/app/Controllers/BaseController.php ./app/Controllers/BaseController.php
cp /var/www/htdocs/mock-old/app/Controllers/Home.php ./app/Controllers/Home.php
cp /var/www/htdocs/mock-old/app/Views/welcome_message.php ./app/Views/welcome_message.php
mv ./Quiz1.php ./app/Controllers/Quiz1.php
mv ./input.php ./app/Views/input.php
mv ./output.php ./app/Views/output.php
sudo chmod -R 777 /var/www/htdocs/mock

# Restart nginx (related to issue #142 on ed)
sudo systemctl restart php8.2-fpm nginx

echo 'Enabling VS Code...'
sudo webprojctl enable vscode
sudo systemctl start code-server@$1
sudo systemctl enable code-server@$1

printf '\nQuiz 1 environment has been set up successfully.\n'
printf 'Your quiz files are located at /var/www/htdocs/mock\n'
