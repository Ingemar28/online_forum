<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.

// $routes->get('/', 'Home::index');
$routes->get('/', 'Login::index');

$routes->get('/login', 'Login::index');
$routes->post('/login/check_login', 'Login::check_login');

$routes->get('/login/logout', 'Login::logout');

$routes->get('/register', 'Register::index');
$routes->post('/register/check_sign_up', 'Register::check_sign_up');

$routes->get('/forum', 'Forum::index');
$routes->post('/forum/newComment', 'Forum::newComment');

$routes->post('/forum/loadMorePosts', 'Forum::loadMorePosts');

$routes->post('/forum/autoComplete', 'Forum::autoComplete');

$routes->post('/forum/search', 'Forum::search');

$routes->get('/forum/posts/(:any)', 'Forum::posts/$1');

$routes->post('/forum/like', 'Forum::like');

$routes->get('/bookmark', 'Bookmark::index');
$routes->post('/bookmark/bookmark', 'Bookmark::bookmark');
$routes->post('/bookmark/deleteBookMark', 'Bookmark::deleteBookMark');

$routes->get('/post', 'Post::index');
$routes->post('/post/upload', 'Post::upload');

$routes->get('/setting', 'Setting::index');
$routes->post('/setting/update', 'Setting::update');
$routes->post('/setting/verify', 'Setting::verify');
$routes->post('/setting/checkCode', 'Setting::checkCode');

$routes->get('/resetPassword', 'ResetPassword::index');
$routes->post('/resetPassword/sendEmail', 'ResetPassword::sendEmail');
$routes->get('/resetPassword/verifyToken', 'ResetPassword::verifyToken');
$routes->post('/resetPassword/changePassword', 'ResetPassword::changePassword');

$routes->get('/socket', 'Socket::index');
// $routes->get('/test', 'testController::index');

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
