<script src="https://hcaptcha.com/1/api.js" async defer></script>
<div class="container">
      <div class="col-4 offset-4">
          <?php //echo $error; ?>
          <?= validation_list_errors() ?>
          <h2 class="text-center">Setting Page</h2>       
          <h3 class="text-center">Hello <?php echo $user->userName ?><h4><br>
          <?php echo form_open(base_url().'setting/verify'); ?>
            <label class="label label-default">Verified : <?php echo $user->verified ?></label>
            <button type="submit" class="btn btn-primary btn-block">Verify Email</button>          
        <?php echo form_close(); ?>
		<?php echo form_open(base_url().'setting/update'); ?>
        <div class="error"><?php echo $error; ?></div>
            <!-- <?php if (isset($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?> -->
					<div class="form-group">
                        <label class="label label-default">Email : <?php echo $user->email ?></label>
						<input type="text" class="form-control" placeholder="Email" required="required" name="email">
					</div>
					<div class="form-group">
                        <label class="label label-default">Phone : <?php echo $user->phone ?></label>
						<input type="text" class="form-control" placeholder="Phone" required="required" name="phone">
					</div>
                    <div class="h-captcha" data-sitekey="50ce27d5-6db2-4c3d-8702-76f27bd17bf0"></div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block">Update</button>
                        <!-- <a href="<?php echo base_url();?>setting/update" class="btn btn-primary btn-block">Update</a> -->
                    </div>
                <?php echo form_close(); ?>

	</div>
</div>