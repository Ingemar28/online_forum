<body id="post">
<script>
    $(document).ready(function() {
    var dropzone = $('#dropzone');
    var uploadArea = $('#uploadfile');
    var fileInput = $('#file');
    
    dropzone.on('dragover', function(e) {
        e.preventDefault();
        $(this).addClass('dragover');
    });
    
    dropzone.on('dragleave', function(e) {
        e.preventDefault();
        $(this).removeClass('dragover');
    });
    
    dropzone.on('drop', function(e) {
        e.preventDefault();
        $(this).removeClass('dragover');
        var files = e.originalEvent.dataTransfer.files;
        fileInput.prop('files', files);
        uploadArea.html('<p>Files selected:</p>');
        $.each(files, function(index, file) {
            uploadArea.append('<p>' + file.name + '</p>');
        });
    });
});
</script>
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/post.css"> -->
    <div class="body_container">
        <?= validation_list_errors() ?>
            <?php echo $error; ?>
            <?= form_open_multipart(base_url().'post/upload', array('enctype' => 'multipart/form-data')) ?>
            <div>
                <div>
                    <input type="checkbox" name="Categoy1" value="Categoy1">
                    <label for="Categoy1"> Categoy 1</label><br>
                    <input type="checkbox" name="Categoy2" value="Categoy2">
                    <label for="Categoy2"> Categoy 2</label><br>
                    <input type="checkbox" name="Categoy3" value="Categoy3">
                    <label for="Categoy3"> Categoy 3</label><br><br>
                </div>
                <label for="subject">Subject</label><br>
                <input required="required" type="text" name="title" placeholder="Title">
                <br><br>
                <textarea name="context" required="required" rows="4" cols="50">Enter text here...</textarea>
                <!-- <input value="Context" type="text" name="context" height="100" width="100"> -->
                <div class="form-group" id="dropzone">
                    <label for="image">Select an Image!!</label><br>
                    <input type="file" name="images[]" multiple="" id="file">
                    <div class="upload-area"  id="uploadfile">
                        <h1>Drag and Drop file here<br/>Or<br/>Click to select file</h1>
                    </div>
                    <!-- <input type="hidden" name="uploaded_files" id="uploaded_files"> -->
                </div>
            </div>
            <br>
            <input type="submit" value="Post">
            <?= form_close() ?>    
        </div>
</body>

