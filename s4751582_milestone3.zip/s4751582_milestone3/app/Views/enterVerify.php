<div class="container">
      <div class="col-4 offset-4">
          <?php //echo $error; ?>
          <?= validation_list_errors() ?>
          <h2 class="text-center">Enter your verified code</h2>       
          <?php echo form_open(base_url().'setting/checkCode'); ?>
            <label class="label label-default">Code :</label>
            <input type="text" class="form-control" placeholder="Code" required="required" name="code">
            <button type="submit" class="btn btn-primary btn-block">Enter</button>          
    </div>
</div>