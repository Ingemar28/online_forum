<div class="container">
      <div class="col-4 offset-4">
        <?= validation_list_errors() ?>
        <?php echo form_open(base_url().'register/check_sign_up'); ?>
        <?php echo $error; ?>
            <h2 class="text-center">Register</h2>       
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Username" required="required" name="username">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Phone number" required="required" name="phone">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Email" required="required" name="email">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" placeholder="Password" required="required" name="password">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" placeholder="Password Confirmation" required="required" name="password_cfm">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block">Sing up</button>
            </div>
        <?php echo form_close(); ?>
	</div>
</div>