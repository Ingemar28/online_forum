<div class="container">
      <div class="col-4 offset-4">
        <?= validation_list_errors() ?>
        <?php echo form_open(base_url().'resetPassword/changePassword'); ?>
        <?php // echo $error; ?>
            <h2 class="text-center">Change Password</h2>    
            <br>   
            <div class="form-group">
                <input type="password" class="form-control" placeholder="New Password" required="required" name="password">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" placeholder="Confirm New Password" required="required" name="password_cfm">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block">Change</button>
            </div>
        <?php echo form_close(); ?>
	</div>
</div>