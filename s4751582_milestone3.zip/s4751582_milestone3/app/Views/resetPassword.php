<div class="container">
      <div class="col-4 offset-4">
          <?php //echo $error; ?>
          <?= validation_list_errors() ?>
          <h2 class="text-center">Enter your user name</h2>
          <br>       
          <?php echo form_open(base_url().'resetPassword/sendEmail'); ?>
            <input type="text" class="form-control" placeholder="Username" required="required" name="username">
            <button type="submit" class="btn btn-primary btn-block">Enter</button>          
          <?php echo form_close(); ?>
    </div>
</div>