<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Button View</title>
</head>
<body>
    <div>
        <h1>Output Page:</h1>
    </div>
    <div>
        <!-- Task 4 - WRITE YOUR CODE HERE -->
        <?php
           echo "Username:" + $date['username'];
           
        ?>
        <!-- Task 4 - END -->
        <form action="<?= site_url('Quiz1/form') ?>" method="post">
            <button type="submit">Go Back!</button>
        </form>
    </div>
</body>
</html>
