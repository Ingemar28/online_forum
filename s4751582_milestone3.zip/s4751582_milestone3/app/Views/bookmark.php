<h2>BookMarks</h2>
<body id="forum">
<script>
    function deleteBookMark(id){
        $.ajax({
            url: "<?php echo base_URL();?>bookmark/deleteBookMark",
            type: "POST",
            data: {id: id},
            dataType: "json",
            success: function(response) {
                // location.reload();
                if (response.redirect) {
                    window.location.href = response.redirect;
                } else {
                    console.log(response);
                }
            }
        });
    }
</script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/forum.css">    
    <div class="body_container">
            <?php 
                $session = session();
                if ($session->get('username') || get_cookie('username')) {?>
            <?php } ?>
        <div class="row2">
        <?php 
            echo $html;
        ?>
        </div>
    </div>
</body>