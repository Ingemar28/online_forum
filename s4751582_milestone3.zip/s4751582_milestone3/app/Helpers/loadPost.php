<php?
if (!function_exists('loadPost')) {
    function loadPost($posts) {
        foreach ($posts as $p) 
        {    
            $html .= '<div class="post">';
            $html .= '<div>';
            $html .= '<img src="'.base_url().'assets/img/user.png " alt="hero icon" class="img-fluid">';

            $html .= '<div>
            <h3>'.$p->title.'</h3>
            <p>'.$p->context.'</p>
            </div>';

            if ($p->badge != "None")
            {
                $html .= '<p>'.$p->badges.'<p>';
            }

            $html .= '</div>';    
            
            $html .= '<div class="buttons">
            <button><i class="bi bi-hand-thumbs-up-fill"></i>
            <span>'.$p->likes.'</span></button><br>';

            if (!empty($p->comments)){
                foreach ($p->comments as $comment){
                    $html .= '<p>'.$comment->text.'</p>';
                }
            }

            $html .= '<textarea id="\''.$p->_id.'\'" name="context" rows="2" cols="30" placeholder="Enter comments here..."></textarea>
            <button onclick="newComment(\''.$p->_id.'\')" class="btn btn-primary btn-sm">Add Comments</button>              
            </div>';

            $html .= '</div>';
        }
        return $html;
    }
}

?>