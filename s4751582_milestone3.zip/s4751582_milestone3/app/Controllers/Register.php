<?php

namespace App\Controllers;
use App\Libraries\MongoDB;
use CodeIgniter\Controller;
use App\Models\UsersModel;
use App\Config\Services;


class Register extends BaseController
{
    public function index()
    {
        $key = bin2hex(random_bytes(16));
        $data = ['key' => $key, 'error' => ''];

        // $data['error'] = "";
        echo view("template/header");
        echo view('register', $data);
        echo view("template/footer");
    }

    public function check_sign_up()
    {
        $username = $this->request->getPost('username');
        $phone = $this->request->getPost('phone');
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $password_cfm = $this->request->getPost('password_cfm');

        helper(['form']);
        $rules = [
            'username' => 'required|alpha_numeric|min_length[4]|max_length[20]',
            'phone' => 'required|numeric|exact_length[10]',
            'email' => 'required|valid_email',
            'password' => 'required|min_length[10]',
            'password_cfm' => 'matches[password]',
        ];

        // password hashing
        $password = password_hash($password, PASSWORD_DEFAULT);

        $data['error'] = "";

        if ($this->validate($rules)) {
            $register = new UsersModel();
            // check if username is unique
            if ($register->check_username($username)){
                // register if username is unique                
                $check = $register->register($username, $phone, $email, $password);
                if (!$check) {
                    echo view("template/header");
                    echo "Something went wrong!";
                    echo view("template/footer");    
                } else {
                    return redirect()->to(base_url('login'));
                }
            } else{
                $data['error'] = "<div class=\"alert alert-danger\" role=\"alert\"> Repeate username!! </div> ";
                echo view("template/header");
                echo view('register', $data);
                echo view("template/footer");
            }
        } else {
            echo view("template/header");
            echo view('register', $data);
            echo view("template/footer");
        }
    }
}

