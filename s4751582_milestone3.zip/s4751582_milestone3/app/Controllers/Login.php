<?php

namespace App\Controllers;
use App\Libraries\MongoDB;
use CodeIgniter\Controller;
use App\Models\UsersModel;
use App\Config\Services;


class Login extends BaseController
{
    public function index()
    {

        $data['error'] = "";
        // check whether the cookie is set or not, if set redirect to welcome page, if not set, check the session
        if (get_cookie('username') && get_cookie('password')) {
            return redirect()->to(base_url('forum'));
        }
        else {
            $session = session();
            $username = $session->get('username');
            $password = $session->get('password');
            if ($username && $password) {
                return redirect()->to(base_url('forum'));
            } else {
                echo view('template/header');
                echo view('login', $data);
                echo view('template/footer');
            }
        }
    }

    public function check_login()
    {
        $data['error'] = "<div class=\"alert alert-danger\" role=\"alert\"> Incorrect username or password!! </div> ";
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $captcha_response = $this->request->getPost('g-recaptcha-response');
        
        $url = 'https://www.google.com/recaptcha/api/siteverify';
        $data = array(
            'secret' => '6Lf8aLYlAAAAAFsvvOTnzjmS51ebBjHKfL4a8hkZ',
            'response' => $captcha_response
        );

        $options = array(
            'http' => array(
                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($data)
            )
        );

        $context  = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $result_json = json_decode($result);

        if (!$result_json->success) {
            // reCAPTCHA validation failed
            $data['error'] = "<div class=\"alert alert-danger\" role=\"alert\"> reCAPTCHA validation failed. Please try again. </div> ";
            echo view('template/header');
            echo view('login', $data);
            echo view('template/footer');
        } else {
            // reCAPTCHA validation succeeded
            $user = new UsersModel();
            $user_data = $user->login($username, $password);
            $if_remember = $this->request->getPost('remember');
            if ($user_data) {
                # Create a session 
                $session = session();
                $session->set('username', $username);
                $session->set('password', $password);
                $session->set('id', $user_data['_id']);
                if ($if_remember) {
                    # Create a cookie
                    setcookie('username', $username, time() + (86400 * 30), "/");
                    setcookie('password', $password, time() + (86400 * 30), "/");
                    setcookie('id', $user_data['_id'], time() + (86400 * 30), "/");
                }
                return redirect()->to(base_url('forum'));
            } else {
                $data['error'] = "<div class=\"alert alert-danger\" role=\"alert\"> Username and Password incorrect! </div> ";
                echo view('template/header');
                echo view('login', $data);
                echo view('template/footer');
            }
        }
    }

    public function logout()
    {
        helper('cookie');
        $session = session();
        $session->destroy();
        //destroy the cookie
        setcookie('username', '', time() - 3600, "/");
        setcookie('password', '', time() - 3600, "/");
        setcookie('scrollTop', '', time() - 3600, "/");
        return redirect()->to(base_url('login'));
    }
}

