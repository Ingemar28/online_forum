<?php

namespace App\Controllers;
use App\Libraries\MongoDB;
use CodeIgniter\Controller;
use App\Models\PostModel;
use App\Models\UsersModel;
use App\Config\Services;
use App\Controllers\Forum;

class Bookmark extends BaseController
{
    
    public function index()
    {
        $user = new UsersModel();
        $session = session();
        $user = $user->getUser($session->get('id'));
        $post = new PostModel();
        $forum = new Forum();
        $html = $forum->loadPost($post->getPostsByBookMark($user->bookmarks), false, true);
        $data = ['html' => $html,
            'pager' => $post->pager];
        
        echo view('template/header');
        echo view('bookmark', $data);
        echo view('template/footer');
    }

    public function bookmark()
    {
        // $response = "Testing";

        $postId = $_POST['id'];
        $session = session();
        $userId = $session->get('id');
        $user = new UsersModel();
        if ($user->bookmark($userId, $postId) ) {
            $response = "Bookmark succeed!";
        } else {
            $response = "This post is already bookmarked!";
        }
    
        echo json_encode($response);
    }

    public function deleteBookMark()
    {
        $postId = $_POST['id'];
        $session = session();
        $userId = $session->get('id');
        $user = new UsersModel();
        $user->deleteBookmark($userId, $postId);
        $response = [
            'redirect' => base_url('bookmark')
        ];

        echo json_encode($response);
    }

}
