<?php

namespace App\Controllers;
use App\Libraries\MongoDB;
use CodeIgniter\Controller;
use App\Models\UsersModel;
use App\Config\Services;
use CodeIgniter\Email\Email;


class Setting extends BaseController
{
    public function index()
    {

        $data = session()->getFlashdata('data');

        $session = session();
        $id = $session->get('id');
        if ($id == null){
            $id = get_cookie('id');
        }

        $userModel = new UsersModel();
        $user = $userModel->getUser($id);

        $data = ['user' => $user,
        'error' => isset($data['error']) ? $data['error'] : ''];
        echo view('template/header');
        echo view('setting', $data);
        echo view('template/footer');
    }

    public function update()
{
    $data = ['error' => ''];

    // Retrieve the hCaptcha response from the form
    $captchaResponse = $this->request->getPost('h-captcha-response');

    // Verify the hCaptcha response
    $hCaptchaSecretKey = '0x39b926c649ac95996D4927009adBC34c599b2984'; // Replace with your hCaptcha secret key
    $hCaptchaVerificationUrl = 'https://hcaptcha.com/siteverify';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $hCaptchaVerificationUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'secret' => $hCaptchaSecretKey,
        'response' => $captchaResponse,
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $hCaptchaResponse = curl_exec($ch);
    curl_close($ch);

    $hCaptchaData = json_decode($hCaptchaResponse);

    if (!$hCaptchaData->success) {
        // hCaptcha verification failed
        $data['error'] = "<div class=\"alert alert-danger\" role=\"alert\"> Please complete the CAPTCHA. </div> ";
        return redirect()->to(base_url('setting'))->with('data', $data);
    }

    // The hCaptcha verification was successful, continue with the rest of the update logic

    $session = session();
    $id = $session->get('id');
    $email = $this->request->getPost('email');
    $phone = $this->request->getPost('phone');

    $rules = [
        'phone' => 'required|numeric|exact_length[10]',
        'email' => 'required|valid_email'
    ];

    $userModel = new UsersModel();
    $user = $userModel->getUser($id);

    if ($this->validate($rules)) {
        if ($userModel->updateUser($id, $email, $phone)) {
            return redirect()->to(base_url('setting'));
        }
    } else {
        $data = ['user' => $user, 'error' => 'Something went wrong!'];
        return redirect()->to(base_url('setting'))->with('data', $data);
    }
}


    // public function update()
    // {
    //     $data = ['error' => ''];

    //     $session = session();
    //     $id = $session->get('id');

    //     $email = $this->request->getPost('email');
    //     $phone = $this->request->getPost('phone');

    //     $rules = [
    //         'phone' => 'required|numeric|exact_length[10]',
    //         'email' => 'required|valid_email'
    //     ];

    //     $userModel = new UsersModel();
    //     $user = $userModel->getUser($id);
        
    //     if ($this->validate($rules)) {
    //         if ($userModel->updateUser($id, $email, $phone))
    //         {
    //             return redirect()->to(base_url('setting'));
    //         }
    //     } else {
    //         $data = ['user' => $user, 'error' => 'Something went wrong!'];
    //         echo view('template/header');
    //         echo view('setting', $data);
    //         echo view('template/footer');
    //     }
    // }

    public function verify()
    {
        $emailHandler = new Email();

        $emailConf = [
            'protocol' => 'smtp',
            'wordWrap' => true,
            'SMTPHost' => 'mailhub.eait.uq.edu.au',
            'SMTPPort' => 25
        ];

        $session = session();
        $id = $session->get('id');
        if ($id == null){
            $id = get_cookie('id');
        }
        $userModel = new UsersModel();
        $user = $userModel->getUser($id);
        $email = $user->email;

        $verifyCode = str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
        $session->set('verifyCode', $verifyCode);

        $emailHandler->initialize($emailConf);
        $emailHandler->setTo($email);
        $emailHandler->setFrom("fengchun.lin@uqconnect.edu.au");
        $emailHandler->setSubject("WIS email verification");
        $emailHandler->setMessage("Hi! Your verify code is $verifyCode");

        if ($emailHandler->send()) {
            echo view('template/header');
            echo "Email sent successfully!";
            echo view('enterVerify');
            echo view('template/footer');
        } else {
            echo "Error sending email. Please try again later.";
            return redirect()->to(base_url('setting'));
        }

    }

    public function checkCode()
    {
        $session = session();
        $verifyCode = $session->get('verifyCode');
        $code = $this->request->getPost('code');
        if ($verifyCode == $code) {
            // change verified to yes in mongodb
            $verifyModel = new UsersModel();
            if ($verifyModel->verified($session->get('id')))
            {
                return redirect()->to(base_url('setting'));
            }
            else {
                echo view('template/header');
                echo "Something went wrong!";
                echo view('enterVerify');
                echo view('template/footer');
            }
        } else {
            echo view('template/header');
            echo "Wrong code!";
            echo view('enterVerify');
            echo view('template/footer');
        }
    }
}

