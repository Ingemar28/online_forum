<?php

namespace App\Controllers;

use App\Libraries\MongoDB;
use CodeIgniter\Controller;
use App\Models\UsersModel;
use App\Config\Services;

class testController extends Controller
{
    protected $users;
   
    public function index()
    {
        // Initialize the MongoDB library
        $data['error'] = "<div class=\"alert alert-danger\" role=\"alert\"> Incorrect username or password!! </div> ";

        // $this->user = new UsersModel();
        $user = new UsersModel();
        // $mvs = $this->mv->getAllMovies();
        // $mvs = $this->mv->getMovieByYear(2008);
        // $mvs = $this->mv->getMovieByCountry();
        $users = $user->getUsers();
        
        //$mvs = $this->mv->getMovieByCountry('UK');
        //$mvs = $this->mv-/>getMovieByRatingAndCountry("8.5","USA");

        // Pass the movies data to the view
        $data = ['users' => $users,
                'pager' => $user->pager,
                'error' => $data['error']];
            
        echo view('template/header');
        echo view('login', $data);
        echo view('template/footer');
        // return view('movie_view', $data);
    }
}