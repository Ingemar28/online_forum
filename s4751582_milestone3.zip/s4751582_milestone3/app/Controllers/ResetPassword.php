<?php

namespace App\Controllers;
use App\Libraries\MongoDB;
use CodeIgniter\Controller;
use App\Models\UsersModel;
use App\Config\Services;
use CodeIgniter\Email\Email;
// use CodeIgniter\Config\Services;



class ResetPassword extends BaseController
{
    public function index()
    {
        echo view("template/header");
        echo view('resetPassword');
        echo view("template/footer");
    }

    public function verifyToken()
    {
        $request = service('request');
        $token = $request->getVar('token');
    
        $session = session();
        $oriToken = $session->get('token');
    
        if ($token == $oriToken) 
        {
            echo view("template/header");
            echo view('changePassword');
            echo view("template/footer");
        } else 
        {
            echo "Invalid token! Please try again.";
        }
    }

    public function changePassword()
    {
        helper(['form']);
        $rules = [
            'password' => 'required|min_length[10]',
            'password_cfm' => 'matches[password]',
        ];
        if ($this->validate($rules)) 
        {
            $session = session();
            $username = $session->get('username');

            $userModel = new UsersModel();
            $user = $userModel->getUserByName($username);

            $password = $this->request->getPost('password');
            $password = password_hash($password, PASSWORD_DEFAULT);

            $userModel->updatePassword($user->_id, $password);

            return redirect()->to(base_url('login'));
        } else {
            echo view("template/header");
            // echo "Password invalid!";
            echo view('changePassword');
            echo view("template/footer");
        }
    }

    public function sendEmail()
    {
        $username = $this->request->getPost('username');
        
        helper(['form']);
        $rules = [
            'username' => 'required|alpha_numeric|min_length[4]|max_length[20]'
        ];
        
        $data['error'] = "";

        if ($this->validate($rules)) {
            // check if username exists
            $userModel = new UsersModel();
            $user = $userModel->getUserByName($username);

            // send a link to the user's email
            $emailHandler = new Email();

            $emailConf = [
                'protocol' => 'smtp',
                'wordWrap' => true,
                'SMTPHost' => 'mailhub.eait.uq.edu.au',
                'SMTPPort' => 25
            ];
    
            $token = bin2hex(random_bytes(16));

            $session = session();
            $session->set('token', $token);
            $session->set('username', $username);

            $url = 'https://infs3202-05282da2.uqcloud.net/project/resetPassword/verifyToken?token='.$token;

            $emailHandler->initialize($emailConf);
            $emailHandler->setTo($user->email);
            $emailHandler->setFrom("fengchun.lin@uqconnect.edu.au");
            $emailHandler->setSubject("WIS Forgot password");
            $emailHandler->setMessage("Hi! Please click this link to reset your password: $url");
    
            if ($emailHandler->send()) {
                return redirect()->to(base_url('login'));
            } else {
                echo "Error sending email. Please try again later.";
                return redirect()->to(base_url('resetPassword'));
            }
    
        }
            
    }

}

