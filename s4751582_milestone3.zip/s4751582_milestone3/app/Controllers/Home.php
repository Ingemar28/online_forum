<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $data['error'] = "";
        echo view('template/header');
        echo view('login', $data);
        echo view('template/footer');
    }
}
