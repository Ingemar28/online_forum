<?php
namespace App\Models;

use CodeIgniter\Model;
use App\Libraries\MongoDB;

class UsersModel extends Model
{
    protected $mongoDb;
    protected $db;
    protected $collection;    
    
    public function __construct()
    {
        $this->mongoDb = new MongoDB();
        $this->db = $this->mongoDb->getDb();
        $this->collection = $this->db->selectCollection('users');       

    }

    public function login($username, $password)
    {
        // $user = $this->collection->findOne(['userName' => $username,
        //     'password' => $password], ['_id'=> 1, 'userName'=> 1]); 
        $user = $this->collection->findOne(['userName' => $username], ['_id'=> 1, 'userName'=> 1, 'password' => 1]);  
        if ($user && password_verify($password, $user->password)) {
            return $user;
        } else {
            return null;
        }
    }

    public function check_username($username)
    {
        $existingUser = $this->collection->findOne(['userName' => $username]);
        if ($existingUser) {
            return false;
        } else {
            return true;
        }
    }

    public function register($username, $phone, $email, $password)
    {
        try {
            $this->collection->insertOne([
                'userName' => $username,
                'password' => $password,
                'phone' => $phone,
                'email' => $email,
                'verified' => 'No'
            ]);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function getUser($id)
    {
        return $this->collection->findOne(['_id' => new \MongoDB\BSON\ObjectId($id)]);
    }

    public function getUserByName($username)
    {
        return $this->collection->findOne(['userName' => $username]);
    }

    public function updateUser($id, $email, $phone)
    {
        try {
            $this->collection->updateOne(
                ['_id' => new \MongoDB\BSON\ObjectId($id)],
                ['$set' => ['email' => $email, 'phone' => $phone]]
            );
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }    

    public function verified($id)
    {
        try {
            $this->collection->updateOne(
                ['_id' => new \MongoDB\BSON\ObjectId($id)],
                ['$set' => ['verified' => 'Yes']]
            );
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function updatePassword($id, $password)
    {
        try {
            $this->collection->updateOne(
                ['_id' => new \MongoDB\BSON\ObjectId($id)],
                ['$set' => ['password' => $password]]
            );
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function bookmark($userId, $postId)
    {
        // return false;
        try {
            // check if user has already bookmarked this post
            if ($this->collection->findOne(
                ['_id' => new \MongoDB\BSON\ObjectId($userId),
                'bookmarks' => new \MongoDB\BSON\ObjectId($postId)])) {
                return false;
            } else {
                $this->collection->updateOne(
                    ['_id' => new \MongoDB\BSON\ObjectId($userId)],
                    ['$push' => ['bookmarks' => new \MongoDB\BSON\ObjectId($postId)]]
                );
                return true;
                }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    public function deleteBookmark($userId, $postId)
    {   
        // $post = new \MongoDB\BSON\ObjectId($postId);

        $this->collection->updateOne(
            ['_id' => new \MongoDB\BSON\ObjectId($userId)],
            ['$pull' => ['bookmarks' => new \MongoDB\BSON\ObjectId($postId)]]
        );
    }
 }