<?php
namespace App\Models;

use CodeIgniter\Model;
use App\Libraries\MongoDB;

class PostModel extends Model
{
    protected $mongoDb;
    protected $db;
    protected $collection;    
    
    public function __construct()
    {
        $this->mongoDb = new MongoDB();
        $this->db = $this->mongoDb->getDb();
        $this->collection = $this->db->selectCollection('post');       

    }

    public function getAllPosts($sort = 'date')
    {
        return $this->collection->find([], ['sort' => ['likes' => -1]]);
    }

    public function getPosts($sort = 'date', $currentPosts = 0)
    {

        return $this->collection->find([], ['sort' => ['likes' => -1], 
        'skip' => $currentPosts,
        'limit' => 5]);

        // return $this->collection->find();
    }

    public function getPostsByBookMark($bookmarks)
    {
        $objectIds = [];
        foreach ($bookmarks as $postId) {
            $objectIds[] = new \MongoDB\BSON\ObjectId($postId);
        }
        return $this->collection->find(['_id' => ['$in' => $objectIds]]);

        // return $this->collection->find();
    }

    public function getPost($id)
    {
        return $this->collection->find(['_id' => new \MongoDB\BSON\ObjectId($id)]);
    }

    public function addNewComment($id, $text)
    {
        return $this->collection->updateOne(
            ['_id' => new \MongoDB\BSON\ObjectId($id)],
            ['$push' => ['comments' => ['_id' => new \MongoDB\BSON\ObjectId(), 'text' => $text]]]);    
    }

    public function autoComplete($tokens)
    {
        $title = [];
        // $context = [];

        foreach ($tokens as $token) {
            array_push($title, ['title' => ['$regex' => '.*'.$token.'.*', '$options' => 'i']] );
            // array_push($context, ['context' => ['$regex' => '.*'.$token.'.*', '$options' => 'i']] );
        }

        // $or = ['$or' => $title];
        // $or = ['$or' => $title, $context];

        return $this->collection->find(['$and'=>$title]);
        // return $this->collection->find($or);
    }

    public function addNewPost($author_id, $title, $context, $fileNames)
    {
        try {
            $this->collection->insertOne([
                'author_id' => new \MongoDB\BSON\ObjectId($author_id),
                'title' => $title,
                'context' => $context,
                'date' => [ '$currentDate' => [ 'type' => 'date' ] ],
                'likes' => 0,
                'badge' => 'None',
                'categories' => 'Lecture',
                'comments' => [],
                'file' => $fileNames
            ]);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }
    
    public function addLike($id)
    {
        try {
            $this->collection->updateOne(
                ['_id' => new \MongoDB\BSON\ObjectId($id)],
                ['$inc' => ['likes' => 1]]);
            return $this->collection->find(
                ['_id' => new \MongoDB\BSON\ObjectId($id)]);
            // return true;
        } catch (\Exception $e) {
            return false;
        }
    }

}