<?php

namespace App\Controllers;

use App\Models\PostModel;

class Post extends BaseController
{
    public function index()
    { 
        $data['error'] = '';
        echo view('template/header');
        echo view('post', $data);
        echo view('template/footer');
    }

    public function upload(){
        helper(['form', 'url']);
        // $rules = [
        //     'images' => 'uploaded[images]|max_size[image,1024]|ext_in[image,jpg,jpeg,png,gif]',
        // ];
        $session = session();
        $author_id = $session->get('id');
        $title = $this->request->getPost('title');
        $context = $this->request->getPost('context');
        $fileNames = [];

        if ($files = $this->request->getFileMultiple('images')) {
            foreach ($files as $img) {
                // $file_rules = array_replace($rules, [$img->getName() => $rules['images']]); 
                // if ($this->validate($file_rules) && $img->isValid() && ! $img->hasMoved()) {
                if ($img->isValid() && ! $img->hasMoved()) {
                    $newName = $img->getRandomName();
                    $img->move(WRITEPATH . 'uploads', $newName);
                    array_push($fileNames, $newName);
                } 
            }
        }

        // wrtie in the data base
        $posting = new PostModel();
        $posting->addNewPost($author_id, $title, $context, $fileNames);
        $data['error'] = '';
        if ($posting){
            return redirect()->to(base_url('forum'));
        } else {
            $data['error'] = $posting->errors();
            echo view('template/header');
            echo view('post', $data);
            echo view('template/footer');
        }
        
    }

    public function postCheck(){
        echo view('template/header');
        echo view('post');
        echo view('template/footer');
    }
}
