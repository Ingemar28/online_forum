<body id="forum">
<script>
    $(document).ready(function() {
        var pos = $.cookie('scrollTop');
        if (pos){
            $(window).scrollTop(pos);
        }
    });
    $(window).scroll(function() {
        var pos = $(this).scrollTop();
        document.cookie = "scrollTop=" + pos;

        if(pos >= $(document).height() - $('.post').height()*3) { 
            setTimeout(function(){
                var el = document.getElementsByTagName("*");
                var numberOfPosts = 0;
                for (var i = 0; i < el.length; i++) {
                    if (el[i].className == 'post') numberOfPosts++;
                }
                console.log(numberOfPosts);
                $.ajax({
                    url: "<?php echo base_URL();?>forum/loadMorePosts",
                    type: "POST",
                    data: {numberOfPosts: numberOfPosts},
                    success: function(response) {
                        $('.post').last().after(response);
                    }
                });
            }, 1000)
        }
    });

    function like(id){
        $.ajax({
            url: "<?php echo base_URL();?>forum/like",
            type: "POST",
            data: {id: id},
            dataType: "json",
            success: function(response) {
                var span = document.getElementById("like"+id);
                span.innerHTML = response;
                span.parentElement.disabled = true;
                // location.reload();
            }
        });
    }

    function bookmark(id){
        $.ajax({
            url: "<?php echo base_URL();?>bookmark/bookmark",
            type: "POST",
            data: {id: id},
            dataType: "json",
            success: function(response) {
                alert(response);
            }
        });
    }
</script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/forum.css">    
    <div class="body_container">
        <h2>
            <?php // if($error = $session->getFlashdata('error')){
                // echo $error;
            // }
            ?>
        </h2>
        <div class="row1">
            <?php 
                $session = session();
                if ($session->get('username') || get_cookie('username')) {?>
            <div>
                <a href="post">New Post</a>
            </div>
            <?php } ?>
            <div>
                <button type="button">Categorie1</button>   
            </div>
            <div>
                <button type="button">Categorie2</button>   
            </div>
            <div>
                <button type="button">Categorie3</button>   
            </div>
        </div>
        <div class="row2">
            <?php 
                echo $html;
            ?>
        </div>
    </div>
</body>