<?php
session_start();

require 'vendor/autoload.php'; // Autoload the Composer dependencies
use MongoDB\Client;

$referrer = $_SERVER['HTTP_REFERER'];
$parts = parse_url($referrer);
$path = trim($parts['path'], '/');
$segments = explode('/', $path);
$lastSegment = end($segments);
if($lastSegment == 'login.php'){
    $temp = new Login();
    $temp->check_login();
}

class Login
{
    // public function index()
    // {
    //     $data['error'] = "";
        
    //     if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
    //         header("Location: forum");
    //         exit();
    //     } else {
    //         if (isset($_SESSION['username']) && isset($_SESSION['password'])) {
    //             header("Location: forum");
    //             exit();
    //         } else {
    //             include('template/header.php');
    //             include('login.php');
    //             include('template/footer.php');
    //         }
    //     }
    // }



    public function check_login()
    {
        $data['error'] = "<div class=\"alert alert-danger\" role=\"alert\"> Incorrect username or password!! </div> ";
        $username = $_POST['username'];
        $password = $_POST['password'];


        // No need to specify the URI, just use the service name as the hostname
        $client = new Client('mongodb://mongodb:27017');

        // Select the MongoDB database and perform operations as needed
        $database = $client->selectDatabase('users');
        $collection = $database->selectCollection('your_user_collection');
        $user_data = $collection->findOne(['username' => $username]);

        $if_remember = isset($_POST['remember']);

        if ($user_data) {
            $_SESSION['username'] = $username;
            $_SESSION['password'] = $password;
            $_SESSION['id'] = $user_data['_id'];

            if ($if_remember) {
                setcookie('username', $username, time() + (86400 * 30), "/");
                setcookie('password', $password, time() + (86400 * 30), "/");
                setcookie('id', $user_data['_id'], time() + (86400 * 30), "/");
            }
            // header("Location: forum");
            exit();
        } else {
            $data['error'] = "<div class=\"alert alert-danger\" role=\"alert\"> Username and Password incorrect! </div> ";
            header("Location: login.php");
        }
    }

    public function logout()
    {
        session_start();
        session_unset();
        session_destroy();
        setcookie('username', '', time() - 3600, "/");
        setcookie('password', '', time() - 3600, "/");
        setcookie('scrollTop', '', time() - 3600, "/");
        header("Location: login");
        exit();
    }
}
?>
