<?php
// Assuming you have started a session elsewhere in your code
?>
<html>
<head>
    <title>INFS3202 Project</title>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="assets/css/forum.css">
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
</head>
<body>
<script>
    // Show select image using file input.
    function readURL(input) {
        document.getElementById('default_img').style.display = 'block';
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                document.getElementById('select').src = e.target.result;
                document.getElementById('select').width = 300;
                document.getElementById('select').height = 200;
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        var searchInput = document.getElementById('search_input');
        searchInput.addEventListener('input', function() {
            var tokens = searchInput.value.split(" ");
            var xhr = new XMLHttpRequest();

            xhr.open("POST", "forum/autoComplete", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    document.querySelector('.dropdown-content').innerHTML = xhr.responseText;
                }
            };

            xhr.send("tokens[]=" + tokens);
        });

        searchInput.addEventListener('focus', function() {
            document.querySelector('.dropdown-content').style.display = 'block';
        });

        searchInput.addEventListener('blur', function() {
            setTimeout(function() {
                document.querySelector('.dropdown-content').style.display = 'none';
            }, 200);
        });
    });
</script>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">INFS3202 Project</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a href="forum"> Home </a>
            </li>
        </ul>
        <form class="form-inline my-2 my-lg-0" method="POST" action="forum/search">
            <input name="search_input" id="search_input" class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
            <div id="myDropdown" class="dropdown-content"></div>
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
        <?php
        // Replace with your authentication logic, assuming you have a $loggedIn variable.
        if ($loggedIn) { ?>
            <!-- <a class="mx-4" href="bookmark"> BookMarks </a> -->
            <!-- <a class="mx-4" href="setting"> Setting </a> -->
            <a class="mx-4" href="login/logout"> Logout </a>
        <?php } else { ?>
            <a class="mx-4" href="login"> Login </a>
        <?php } ?>
    </div>
</nav>
<div class="container">
